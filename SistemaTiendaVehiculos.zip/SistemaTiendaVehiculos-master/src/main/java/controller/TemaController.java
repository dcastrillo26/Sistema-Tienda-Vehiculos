/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;

/**
 *
 * @author ProyectoGrupo4
 */
@Named(value = "temaController")
@SessionScoped
public class TemaController implements Serializable {
    
    private String tema;    

    /**
     * Creates a new instance of TemaController
     */
    public TemaController() {
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }
    
}
